% 21 Crie um predicado ncombinacoes(M,P,N) que calcule o nuumero total N
% de combinacoes simples possiveis em uma lista com M elementos,
% tomados P a P. Use este predicado para calcular o nuumero de
% diferentes combinacoes para os dois exercicios anteriores e
% verifique se todas elas foram geradas.
