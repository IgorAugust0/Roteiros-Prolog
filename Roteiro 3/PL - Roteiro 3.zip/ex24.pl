% 24. Crie um predicado narranjos(M,P,N) que calcule o nuumero total N
% de arranjos simples possiveis em uma lista com M elementos, tomados
% P a P. Use este predicado para calcular o numero de diferentes
% arranjos para os dois exercicios anteriores e verifique se todos eles
% foram gerados.
